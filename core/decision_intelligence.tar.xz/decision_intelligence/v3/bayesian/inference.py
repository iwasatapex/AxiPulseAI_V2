from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class BayesianResult:
    distribution: Any


class BayesianInferenceEngine:
    """
    V3 compatibility boundary for Bayesian inference.

    This class uses the canonical ``core.probabilistic`` adapter
    for all Bayesian inference.
    """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        self._args = args
        self._kwargs = kwargs

    def run(self, *args: Any, **kwargs: Any) -> BayesianResult:
        if args or kwargs:
            return self.infer(*args, **kwargs)
        return self.infer(*self._args, **self._kwargs)

    def infer(
        self,
        observations: list[float] | None = None,
        prior_mean: float = 0.5,
        prior_strength: float = 2.0,
        credible_level: float = 0.95,
    ) -> BayesianResult:
        """
        Perform Bayesian inference using the canonical probabilistic adapter.

        Uses the canonical ``core.probabilistic`` adapter for scalar inference.
        """
        from core.probabilistic.adapter import UniversalProbabilisticAdapter

        adapter = UniversalProbabilisticAdapter()

        # For scalar Bayesian inference on [0,1] observations
        obs = [float(v) for v in (observations or [])]

        result = adapter.from_bayesian(
            observations=obs,
            prior_mean=prior_mean,
            prior_strength=prior_strength,
            credible_level=credible_level,
        )

        return BayesianResult(
            distribution=result.bayesian,
        )


def infer(*args: Any, **kwargs: Any) -> BayesianResult:
    """Module-level convenience for the V3 Bayesian inference."""
    engine_type = BayesianInferenceEngine
    return engine_type().infer(*args, **kwargs)


__all__ = ["BayesianInferenceEngine", "ProbabilisticDecision", "analyze"]
